package com.grab.backend;

public class AfterLogin {

	public static void main(String[] args) throws Exception {
		
		// make a 2d list of content and collab and passs to get hybrid rank	
		
		/*ComputeContentSimilarity.computeSimilarity();
		
		
		BuildSimilarityMatrix.buildSimilarityMatrix();
		 collab= Pearson.computePearson();
		PredictedRating.predict();
		
		HybridRecommend.computeHybridRank(content,collab);*/
	}

}
