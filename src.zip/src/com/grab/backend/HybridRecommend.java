package com.grab.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HybridRecommend {

	public static void main(String[] args) {
		try {
			BufferedReader content= new BufferedReader(new FileReader("data/test/finalcosinecontent_similarity.csv"));
			BufferedReader collab= new BufferedReader(new FileReader("data/test/finalItemPearson.csv"));
			BufferedWriter hybrid= new BufferedWriter(new FileWriter("data/test/finaluploadhybrid.csv"));
			List<String[]> cont = new ArrayList<String[]>();
			List<String[]> colab = new ArrayList<String[]>();
			String thisLine="",thatLine="";
			int xx=0;
			while ((thisLine =content.readLine()) != null) {
		        cont.add(thisLine.split(","));
		      if(xx>1000)
		    	  break;
		      xx++;
		      
		}
			while ((thatLine =collab.readLine()) != null) {
		        colab.add(thatLine.split(","));
		       
		      
		}
			int rows = cont.size();
			int cols = cont.get(0).length;
			  System.out.println(rows);
			  System.out.println(cols);
			  System.out.println(cont.get(1).length);
			double hyb=0;
			int mm=0;
			for(int i=1;i<colab.get(0).length;i++)
			{
				if(i==100)
					break;
				for(int j=1;j<colab.get(1).length;j++)
				{
					if(j==100)
						break;
					if(Double.parseDouble(colab.get(i)[j])==0)
					{//System.out.println(cont.get(i)[j]);
						hyb=Double.parseDouble(cont.get(i)[j]);
					}
					else if(Double.parseDouble(cont.get(i)[j])==0)
					{//System.out.println("b");
						hyb=Double.parseDouble(colab.get(i)[j]); 
					}
					else if(Double.parseDouble(colab.get(i)[j])!=0&&Double.parseDouble(cont.get(i)[j])!=0)
					{
						//System.out.println("Content="+cont.get(i)[j] +"Collab="+colab.get(i)[j]);
						hyb = (Double.parseDouble(cont.get(i)[j])+Double.parseDouble(colab.get(i)[j]))/2;
						//System.out.println(j+""+hyb);
					}
					else
						hyb=0;
					mm++;
					hybrid.append(mm+",");
					hybrid.append(cont.get(0)[i]+",");	
					
					hybrid.append(cont.get(j)[0]+",");
					hybrid.append(hyb+"\n");
					hybrid.flush();
				}
				
				hybrid.flush();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
