package com.grab.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class checkSame {

	public static void main(String[] args) {
	
		try {
		Map<String,Integer> dataCount=new HashMap<String,Integer>();
		List<String> same = new ArrayList<String>();
		//BufferedReader br = new BufferedReader(new FileReader("data/test/ratingsszz.csv"));
		String thisLine, thatLine;
		String[] st = null;
		BufferedReader bs = new BufferedReader(new FileReader("data/test/finalmoviedata.csv"));

		while ((thatLine = bs.readLine()) != null) {
		        st = thatLine.split(",");
		                
		        same.add(st[0]);
		}
		System.out.println(same.size());
		BufferedWriter bw = new BufferedWriter(new FileWriter("data/test/new_movie_data.csv"));
		int l=0;
		int k=0;
	
	int cc = 0, dd = 0;
	            
	            
	            System.out.println(same.size());
	//BufferedWriter bw = new BufferedWriter(new FileWriter("data/test/finalsrating.csv"));
		BufferedWriter bww = new BufferedWriter(new FileWriter("data/test/finalmoviedata.csv"));
		
		
		
				
				
				i=0;
				String[][]matrix =new String[45468][7];
				String[][] temps = new String[5344][7];
				
				while ((lin = bss.readLine()) != null) {
					
					st = lin.split(",");
					
				    for(int j=0;j<7;j++)
				    	{
				    	try {
				    		matrix[i][j]=st[j];
				    		
				    		//System.out.println(st[j]);
				    	}catch(Exception e)
				    	{
				    		matrix[i][j]="undefined";
				    	}
				    		
				    	}
				    
				   // System.out.println();
				   
				    i++;
				}
				int m=0;
				
					for( l=0;l<5344;l++)
					{
						for( i=0;i<45468;i++) {
						if(same.get(l).equals(matrix[i][0])){
							
							for( k=0;k<7;k++) {
								
								
								temps[m][k]=matrix[i][k];
								
								System.out.println(temps[m][k]);
								System.out.println(m);
								
							}
							m++;
							break;
							
							
						}
					}
					
				}
				for( i=0;i<9;i++) {
					bww.append(matrix[0][i]+",");
				}
				bww.append("\n");
				bww.flush();
				for( i=0;i<5344;i++) {
					//bw.append(matrix[i][0]+",");
					for(int j=0;j<9;j++) {
						//System.out.print(temp[i][j]+" ");
						bww.append(temps[i][j]+",");
					}
					//System.out.println("");
					bww.append("\n");
					bww.flush();
				}
				
        bw.close();
      
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

}