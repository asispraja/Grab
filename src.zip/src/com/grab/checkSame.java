package com.grab.backend;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class checkSame {

	public static void main(String[] args) {
	
		try {
		Map<String,Integer> dataCount=new HashMap<String,Integer>();
		List<String> same = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader("data/test/ratingsszz.csv"));
		String thisLine, thatLine;
		String[] st = null;
		BufferedReader bs = new BufferedReader(new FileReader("data/test/finalmoviedata.csv"));

		while ((thatLine = bs.readLine()) != null) {
		        st = thatLine.split(",");
		                
		        same.add(st[0]);
		}
		System.out.println(same.size());
		BufferedWriter bw = new BufferedWriter(new FileWriter("data/test/finalsrating.csv"));
		
			
			String lin=null;
			String[][] temp = new String[5344][5344];
			
			String[][]matric =new String[2500][22031]; 
			int i=0;
			while ((lin = br.readLine()) != null) {
				if(i==2500)
					break;
				st = lin.split(",");
				//System.out.println(i);
			    for(int j=0;j<22031;j++)
			    	{
			    	
			    		matric[i][j]=st[j];
			    		
			    	}
			    i++;
			}
			br.close();
			System.out.println(matric[1].length);
			System.out.println(matric.length);
					int l=0;
					int k=0;
					for( i=0;i<same.size();i++) {
						
						for(int j=0;j<matric[1].length;j++) {
							
							System.out.println(same.get(i));
							if(same.get(i).equals(matric[0][j])){
								
								for( k=0;k<matric.length;k++) {
									
									//System.out.println(matric[k][j]);
									temp[k][l]=matric[k][j];
									
								}
								l++;
								break;
							}
							
						}
					}
					
					for( i=0;i<matric.length;i++) {
						bw.append(matric[i][0]+",");
						for(int j=0;j<l;j++) {
							//System.out.print(temp[i][j]+" ");
							bw.append(temp[i][j]+",");
						}
						//System.out.println("");
						bw.append("\n");
						bw.flush();
					}
					
					
	        bw.close();
	      
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
