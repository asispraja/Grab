package com.grab.frontend;

import java.awt.Choice;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Description {

	private JFrame frame;
	String movieId, userId;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Description window = new Description();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Description() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		
		
		JLabel lblThumbnail = new JLabel("");
		lblThumbnail.setBounds(34, 23, 188, 302);
		lblThumbnail.setIcon(new ImageIcon("data/finalimage/star wars.jpg"));
		frame.getContentPane().add(lblThumbnail);
		
		JLabel lblNewLabel = new JLabel("NAME OF MOVIE");
		lblNewLabel.setBounds(244, 39, 411, 41);
		lblNewLabel.setFont(new Font("Viner Hand ITC", Font.PLAIN, 30));
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblDescription = new JLabel("DESCRIPTION");
		lblDescription.setFont(new Font("Arial", Font.BOLD, 11));
		lblDescription.setBounds(244, 91, 73, 14);
		frame.getContentPane().add(lblDescription);
		
		Choice choice = new Choice();
		choice.addItem("1");
		choice.addItem("2");
		choice.addItem("3");
		choice.addItem("4");
		choice.addItem("5");
		
		choice.setBounds(469, 305, 92, 47);
		frame.getContentPane().add(choice);
		
		
		JLabel lblRateAMovie = new JLabel("RATE A MOVIE");
		lblRateAMovie.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblRateAMovie.setBounds(244, 284, 136, 41);
		frame.getContentPane().add(lblRateAMovie);
		
		JLabel lblNewLabel_1 = new JLabel("describe");
		lblNewLabel_1.setBounds(244, 116, 339, 41);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.setBounds(270, 342, 107, 41);
		btnNewButton.addMouseListener(new MouseAdapter()
				{
					@Override
					public void mouseClicked(MouseEvent e)
					{
						String sql ="Update Ratings set "+movieId+"= "+choice.getSelectedItem()+"where userid="+userId;
						frame.dispose();
					}
				});
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.setBounds(411, 338, 116, 48);
		frame.getContentPane().add(btnNewButton_1);
		frame.setBounds(0, 0,700, 468);
		btnNewButton_1.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				String sql ="Update Ratings set "+movieId+"= "+choice.getSelectedItem()+"where userid="+userId;
				frame.dispose();
			}
		});

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
