package com.grab.frontend;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.FlowLayout;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import java.awt.GridLayout;
import javax.swing.JSpinner;

public class Language extends JFrame {

	private JPanel contentPane;
	String[] language= {"English","Chinese","French","Japnase","Korean","Austrailain","Poland"};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Language frame = new Language();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Language() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1360, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(584, 188, 662, 515);
		contentPane.add(scrollPane);
		
		JPanel nayapannel = new JPanel();
		nayapannel.setBorder(null);
		nayapannel.setBackground(new Color(255, 255, 255));
		scrollPane.setViewportView(nayapannel);
		nayapannel.setLayout(new GridLayout(1, 1, 1, 1));
		
	
		
		JLabel lblGenre = new JLabel("GENRE");
		lblGenre.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SelectionPaage.main(null);
				dispose();
				System.out.println("GENRE");
				int x=628;
				int y=263;
				JLabel[] lblAction= new JLabel[9];
				JLabel[] thumb = new JLabel[9];
				for(int i=0;i<9;i++)
				{
					
				
				lblAction[i]= new JLabel(language[i]);
				lblAction[i].setFont(new Font("Tahoma", Font.PLAIN, 16));
				lblAction[i].setForeground(Color.BLACK);
				lblAction[i].setBounds(x, y, 100, 47);
				contentPane.add(lblAction[i]);
				thumb[i] = new JLabel(new ImageIcon("data/ima/mythumb"+(i+1)+".jpg"));
				
				thumb[i].setBounds(x, y-146, 127, 183);
				contentPane.add(thumb[i]);
				
				x=x+200;
				if(i%3==2)
				{
					y=y+200;
					x=628;
				}
				}
			}
		});
		lblGenre.setFont(new Font("Arial Black", Font.PLAIN, 52));
		lblGenre.setForeground(Color.WHITE);
		lblGenre.setBounds(68, 188, 409, 47);
		contentPane.add(lblGenre);
		
		JLabel lblLanguage = new JLabel("LANGUAGE");
		lblLanguage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Language.main(null);
				dispose();
			}		
		});
		lblLanguage.setForeground(new Color(255, 0, 0));
		lblLanguage.setFont(new Font("Arial Black", Font.PLAIN, 52));
		lblLanguage.setBounds(68, 301, 409, 47);
		contentPane.add(lblLanguage);
		
		JLabel lblCountry = new JLabel("COUNTRY");
		lblCountry.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Country.main(null);
				dispose();
			}
		});
		lblCountry.setForeground(Color.WHITE);
		lblCountry.setFont(new Font("Arial Black", Font.PLAIN, 52));
		lblCountry.setBounds(54, 407, 409, 47);
		contentPane.add(lblCountry);
		
		JLabel lblYear = new JLabel("YEAR");
		lblYear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Year.main(null);
				dispose();
			}
		});
		lblYear.setForeground(Color.WHITE);
		lblYear.setFont(new Font("Arial Black", Font.PLAIN, 52));
		lblYear.setBounds(59, 514, 409, 47);
		contentPane.add(lblYear);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("res/image/line.png"));
		label_1.setBounds(28, 180, 512, 66);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("res/image/line.png"));
		label_2.setBounds(28, 290, 512, 66);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon("res/image/line.png"));
		label_3.setBounds(28, 396, 512, 66);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon("res/image/line.png"));
		label_4.setBounds(28, 506, 512, 66);
		contentPane.add(label_4);
		

		JLabel label_5 = new JLabel(new ImageIcon("res/image/profile.png"));
		label_5.setBounds(10, 53, 80, 80);
		contentPane.add(label_5);
		
		JLabel lblSelectProperties = new JLabel("USER Name");
		lblSelectProperties.setFont(new Font("Tahoma", Font.PLAIN, 39));
		lblSelectProperties.setForeground(Color.WHITE);
		lblSelectProperties.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectProperties.setBounds(110, 53, 458, 72);
		contentPane.add(lblSelectProperties);
		
		JLabel label = new JLabel("");
		label.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		label.setIcon(new ImageIcon("res/image/homeplain1.png"));
		label.setBounds(38, 11, 1344, 719);
		contentPane.add(label);
	}
}
